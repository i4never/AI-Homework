#include <iostream>
#include <iomanip>
#include <ctime>
#include <cmath>
#include <fstream>
using namespace std;

int num;

//Structure Define
class Hanoi{
public:
	int **t;	//��ά3*num���飬���ڱ�ʾ������
	int g;
	Hanoi *father;
	Hanoi *child[6];
public:
	Hanoi();
	void get(int **a);
	void show();
	void expand();
	int h();
};

class TableNode
{
public:
	Hanoi * p;
	int A;
	TableNode * front;
	TableNode * next;
public:
	TableNode();
	void link (Hanoi *p);
};

TableNode *open,*close;
Hanoi Showheadnode;

//Function Define
Hanoi::Hanoi()		//���캯������ʼ��
{
	g=0;
	t=new int*[3];
	for (int i=0;i<num;i++)
	{
		t[0]=new int[num];
		t[1]=new int[num];
		t[2]=new int[num];
	}

	for (int i=0;i<3;i++)
	{
		for  (int j=0;j<num;j++)
		{
			t[i][j]=0;
		}
	}

	for (int i=0;i<6;i++)
		child[i]=NULL;
	father=NULL;
}

int Hanoi:: h()
{
	//�����پ���
	 
	int hn=0;
	for (int i=0;i<3;i++)
	{
		for (int j=0;j<num;j++)
		{
			if (t[i][j]!=0)
				hn+=abs(2-i)+abs(t[i][j]-1-j);
		}
	}
	return hn;

	//ȥ������ע���м�Ϊ�����������

	return 0;

	//ʣ�ಽ��
	/*
	int hn=0;
	int *a;
	int c=3;
	a=new int[num+1];
	for (int i=0;i<3;i++)
	{
		for (int j=0;j<num;j++)
		{
			if (t[i][j]==0)
				continue;
			a[t[i][j]]=i+1;
		}
	}

	for (int i=num;i>0;i--)
	{
		if (a[i]!=c)
		{
			hn+=pow(2,i);
			c=6-a[i]-c;
		}
	}

	return hn;
	*/
}

void Hanoi:: show()
{
	cout<<"g(n)="<<g<<"   h(n)"<<this->h()<<endl;
	for (int i=0;i<3;i++)
	{
		cout<<"����"<<i+1<<"   ";
	}
	cout<<endl;

	for (int j=0;j<num;j++)
	{
		for  (int i=0;i<3;i++)
		{
			cout<<setiosflags(ios::left)<<setw(8)<<t[i][j];
		}
		cout<<endl;
	}
	
}

void Hanoi:: get(int **a)
{
	for (int i=0;i<3;i++)
		for (int j=0;j<num;j++)
			this->t[i][j]=a[i][j];
}

void Hanoi:: expand()
{
	int c=0,j1,j2;
	for (int i=0;i<3;i++)
	{
		if (t[i][num-1]==0)
			continue;
		
		for (j1=0;j1<num;j1++)
		{
			if (t[i][j1] != 0)
				break;
		}


		for (int p=1;p<3;p++)
		{
			child[c]=new Hanoi;
			child[c]->get(this->t);
			child[c]->father=this;
			child[c]->g=this->g+1;
			for (j2=0;j2<num;j2++)
			{
				if (child[c]->t[(i+p)%3][j2]!=0)
					break;
			}
			j2--;

			child[c]->t[(i+p)%3][j2]=child[c]->t[i][j1];
			child[c]->t[i][j1]=0;
			if (j2==num-1)
			{
				c++;
			}
			else
			{
				if (child[c]->t[(i+p)%3][j2] > child[c]->t[(i+p)%3][j2+1])
				{
					delete child[c];
					child[c]=NULL;
				}
				else
				{
					c++;
				}
			}			
		}
	}
}

bool same(Hanoi a,Hanoi b)	//����״̬��ȷ���true�����򷵻�false
{
	
	for (int i=0;i<3;i++)
		for (int j=0;j<num;j++)
		{
			if (a.t[i][j]!=b.t[i][j])
				return false;
		}
	return true;
}

TableNode::TableNode()
{
	A=0;
	p=NULL;
	front=NULL;
	next=NULL;
}

void TableNode::link(Hanoi *p)
{
	this->p=p;
	A=this->p->g+this->p->h();
}

void add_to_opentable(TableNode *p)		//����չ�����Ľڵ����open��
{
	p->next=open->next;
	p->front=open;
	if (open->next != NULL)
		open->next->front=p;
	open->next=p;
}

void add_to_closetable(TableNode *p)	//����չ���Ľڵ����close��
{
	TableNode *q;
	q=new TableNode;
	q->A=p->A;
	q->p=p->p;
	if(close != NULL)
	{
		q->next=close->next;
		q->front=close;
		if (close->next != NULL)
			close->next->front=q;
		close->next=q;
		
	}
	else
	{
		close=q;
	}
}

void delete_from_opentable(TableNode *p)	//��open����ɾ����չ�Ľڵ�
{
	if (p->front != NULL)
	{
			if (p->next != NULL)
			{
				p->front->next=p->next;
				p->next->front=p->front;
			}
			else
			{
				p->front->next=NULL;
			}
		}
		else
		{
			if (p->next != NULL)
			{
				p->next->front=NULL;
				open=p->next;
			}
			else
			{
				cout<<"�޽�"<<endl;
				exit(0);
			}
		}

}

bool expanded(Hanoi *p)	//��close����Ƚϣ��жϽڵ��Ƿ��Ѿ���չ
{
	TableNode *q;
	q=close;
	if (q==NULL)
		return false;
	
	while (q!=NULL)
	{
		if (same(*p,*q->p) == true)
			return true;
		q=q->next;
	}
	return false;
}

TableNode * search_min()	//����open����A��С�Ľڵ�
{
	/*�����������
	return open;
	*/
		
	TableNode *p,*q;
	p=open;
	q=open;
	int A=99999;
	while (p!=NULL)
	{
		if (p->A < A)
		{
			A=p->A;
			q=p;
		}
		p=p->next;
	}
	return q;
	
}

void InsertToShow(Hanoi *state)
{
		state->child[0] = Showheadnode.child[0];
		Showheadnode.child[0] = state;
}


int main()
{
	int **a;
	a=new int*[3];
	cout<<"�����뺺ŵ������"<<endl;
	cin>>num;
	while (num<=0)
	{
		cout<<"���������0������"<<endl;
		cin>>num;
	}
	for (int i=0;i<num;i++)
	{
		a[0]=new int[num];
		a[1]=new int[num];
		a[2]=new int[num];
	}

	for (int i=0;i<num;i++)
		a[0][i]=i+1;

	for (int i=1;i<3;i++)
		for  (int j=0;j<num;j++)
			a[i][j]=0;
		

	Hanoi start,final;
	start.get(a);
	final.get(a);

	for (int i=0;i<num;i++)
	{
		final.t[2][i]=final.t[0][i];
		final.t[0][i]=0;
	}
	
	int count=0;

	Hanoi *eptr;
	TableNode *tptr,*minptr;

	open=new TableNode;
	open->link(&start);
	close=NULL;

	clock_t s,finish;
	double time=0.0;
	s=clock();
	while(open!=NULL)
	{
		minptr=search_min();

		if (same(*minptr->p,final))	//h����=0��Ϊ����״̬
		{
			break;
		}

		eptr=minptr->p;
		//��չ�ڵ㲢����open��
		eptr->expand();
		int i=0;
		while (eptr->child[i] != NULL && i<6)
		{
			tptr=new TableNode;
			tptr->link(eptr->child[i]);
			if ( expanded(tptr->p) == false)
			{
				//cout<<"add!"<<endl;
				add_to_opentable(tptr);
				count++;
			}
			else
			{
				//cout<<"not add!"<<endl;
			}
			i++;
			//system("pause");
		}

		//��open����ɾ����չ�ڵ㲢����close��
		add_to_closetable(minptr);
		delete_from_opentable(minptr);
	}
	finish=clock();
	time=(double)(finish-s)/CLOCKS_PER_SEC;

	Hanoi *p;
	p=minptr->p;
	while (p->father != NULL)
	{
		InsertToShow(p);
		p=p->father;
	}

	p = Showheadnode.child[0];
	while (p->child[0] != NULL){
		p->show();
		p = p->child[0];
	}

	p->show();


	
	cout<<endl;
	cout<<"��չ�ڵ�����"<<count<<endl;
	cout<<"����ʱ�䣺"<<time<<"s"<<endl;
	system("pause");
	return 0;
}