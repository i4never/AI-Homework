#include <iostream>
#include <ctime>
using namespace std;

//Structure define
class Eightpuzzle
{
public:
	int cd[3][3];
	int g;
	Eightpuzzle * father;
	Eightpuzzle * child[4];

public:
	Eightpuzzle();			//���캯��
	int h();				//h��n��
	void show ();			//��ʾ����
	void expand();			//��չ����
	void cdget(int a[3][3]);		//�ı�״̬
};

class TableNode
{
public:
	Eightpuzzle * p;
	int A;
	TableNode * front;
	TableNode * next;
public:
	TableNode();
	void link (Eightpuzzle *p);
};

TableNode *open,*close;
Eightpuzzle *start;

//Funcation define
Eightpuzzle::Eightpuzzle()
{
	int cd[3][3]={{0,0,0},{0,0,0},{0,0,0}};
	g=0;
	father=NULL;
	child[0]=NULL;
	child[1]=NULL;
	child[2]=NULL;
	child[3]=NULL;
}

int Eightpuzzle::h()	//��������
{
	//����λ�������
	/*
	int hn=0;
	int temp=1;
	for (int i=0;i<3;i++)
	{
		for (int j=0;j<3;j++)
		{
			if (cd[i][j]!=0 && cd[i][j]!=temp)
				hn++;
			temp++;
		}
	}
	return hn;
	*/

	//�����پ���
	
	int hn=0;
	
	for (int i=0;i<3;i++)
	{
		for (int j=0;j<3;j++)
		{
			switch(this->cd[i][j])
			{
			case 1:hn+=abs(i-0)+abs(j-0);break;
			case 2:hn+=abs(i-0)+abs(j-1);break;
			case 3:hn+=abs(i-0)+abs(j-2);break;
			case 4:hn+=abs(i-1)+abs(j-0);break;
			case 5:hn+=abs(i-1)+abs(j-1);break;
			case 6:hn+=abs(i-1)+abs(j-2);break;
			case 7:hn+=abs(i-2)+abs(j-0);break;
			case 8:hn+=abs(i-2)+abs(j-1);break;
			default:;break;
			}
		}
	}
	return hn;
	
}

void Eightpuzzle::expand()	//��չ�ڵ�
{
	int c=0;
	int i,j;
	int tag=0;
	for (i=0;i<3;i++)
	{
		for (j=0;j<3;j++)
		{
			if (cd[i][j]==0)
			{
				if (i-1>=0)	//�Ϸ�δԽ��
				{
					this->child[c]=new Eightpuzzle;
					this->child[c]->g=this->g+1;
					this->child[c]->father=this;
					this->child[c]->cdget(this->cd);
					this->child[c]->cd[i][j]=this->child[c]->cd[i-1][j];
					this->child[c]->cd[i-1][j]=0;
					c++;
				}
				if (i+1<=2)	//�·�δԽ��
				{
					this->child[c]=new Eightpuzzle;
					this->child[c]->g=this->g+1;
					this->child[c]->father=this;
					this->child[c]->cdget(this->cd);
					this->child[c]->cd[i][j]=this->child[c]->cd[i+1][j];
					this->child[c]->cd[i+1][j]=0;
					c++;
				}
				if (j-1>=0)	//��δԽ��
				{
					this->child[c]=new Eightpuzzle;
					this->child[c]->g=this->g+1;
					this->child[c]->father=this;
					this->child[c]->cdget(this->cd);
					this->child[c]->cd[i][j]=this->child[c]->cd[i][j-1];
					this->child[c]->cd[i][j-1]=0;
					c++;
				}
				if (j+1<=2)	//�ҷ�δԽ��
				{
					this->child[c]=new Eightpuzzle;
					this->child[c]->g=this->g+1;
					this->child[c]->father=this;
					this->child[c]->cdget(this->cd);
					this->child[c]->cd[i][j]=this->child[c]->cd[i][j+1];
					this->child[c]->cd[i][j+1]=0;
					c++;
				}
				return ;
			}
		}
	}
}

void Eightpuzzle::cdget(int a[3][3])	//��ȡ����״̬
{
	for (int i=0;i<3;i++)
		for (int j=0;j<3;j++)
			this->cd[i][j]=a[i][j];
}

void Eightpuzzle::show()	//��ʾƴͼ״̬
{
	cout<<"g(n):"<<g<<"	"<<"h(n):"<<h()<<endl;
	for (int i=0;i<3;i++)
	{
		for (int j=0;j<3;j++)
			cout<<cd[i][j]<<"  ";
		cout<<endl;
	}
}

TableNode::TableNode()
{
	A=0;
	p=NULL;
	front=NULL;
	next=NULL;
}

void TableNode::link(Eightpuzzle *p)	//����TableNode�е���Ϣ
{
	this->p=p;
	A=this->p->g+this->p->h();
}

void add_to_opentable(TableNode *p)		//����չ�����Ľڵ����open��
{
	p->next=open->next;
	p->front=open;
	if (open->next != NULL)
		open->next->front=p;
	open->next=p;
}

void add_to_closetable(TableNode *p)	//����չ���Ľڵ����close��
{
	TableNode *q;
	q=new TableNode;
	q->A=p->A;
	q->p=p->p;
	if(close != NULL)
	{
		q->next=close->next;
		q->front=close;
		if (close->next != NULL)
			close->next->front=q;
		close->next=q;
		
	}
	else
	{
		close=q;
	}
}

void delete_from_opentable(TableNode *p)	//��open����ɾ����չ�Ľڵ�
{
	if (p->front != NULL)
	{
			if (p->next != NULL)
			{
				p->front->next=p->next;
				p->next->front=p->front;
				//cout<<"�м�ɾ��"<<endl;
				//delete minptr;
			}
			else
			{
				//minptr->p->show();
				p->front->next=NULL;
				//cout<<"ĩβɾ��"<<endl;
			}
		}
		else
		{
			if (p->next != NULL)
			{
				p->next->front=NULL;
				open=p->next;
				//cout<<"ͷɾ��"<<endl;
				//delete minptr;
			}
			else
			{
				cout<<"�޽�"<<endl;
				exit(0);
			}
		}

}

bool expanded(Eightpuzzle *p)	//��close����Ƚϣ��жϽڵ��Ƿ��Ѿ���չ
{
	TableNode *q;
	q=close;
	if (q==NULL)
		return false;
	int tag;
	while (q!=NULL)
	{
		tag=0;
		for (int i=0;i<3;i++)
		{
			for (int j=0;j<3;j++)
			{
				if (p->cd[i][j] != q->p->cd[i][j])
				{
					tag=1;
				}
			}
		}
		if (tag==0)
			return true;
		q=q->next;
	}
	return false;
}

TableNode * search_min()	//����open����A��С�Ľڵ�
{
	/*�����������
	return open;
	*/
	
	
	
	TableNode *p,*q;
	p=open;
	q=open;
	int A=99999;
	while (p!=NULL)
	{
		if (p->A < A)
		{
			A=p->A;
			q=p;
		}
		p=p->next;
	}
	return q;
	
}

void showresult(Eightpuzzle *p)		//��ʾ�ƶ����� 
{
	if (p!=NULL)
	{
		
		showresult(p->father);
		cout<<"��"<<p->g<<"��"<<endl;
		p->show();
	}
}

void judge(Eightpuzzle *p)	//�ж��Ƿ��н�
{
	int a[9];
	int c=0;
	for (int i=0;i<3;i++)
		for (int j=0;j<3;j++)
			a[c++]=p->cd[i][j];
	
	int sum=0;
	for (int i=0; i<9; i++ )
		for(int j=0;j<i;j++)
		{
			if( a[i] * a[j])
			{
				if( a[j] < a[i])
					sum++;
			}
		
		}
	if (sum%2 != 0)
	{
		cout<<"�޽�"<<endl;
		exit(0);
	}
}

void inputpuzzle(Eightpuzzle *p)	//����Ϸ��Լ��
{
	int a[3][3];
	cout<<"�������ʼ״̬����0~8��ʾ"<<endl;
	for (int i=0;i<3;i++)
	{
		for (int j=0;j<3;j++)
		{
			while(cin>>a[i][j]<0 || a[i][j]>8)
			{
				cout<<"����Ƿ�������������"<<endl;
			}
		}
	}
	p->cdget(a);
}

int main()
{
	int count=0;
	start=new Eightpuzzle;
	
	inputpuzzle(start);
	cout<<"��ʼ״̬��"<<endl;
	start->show();
	cout<<endl;
	judge(start);

	Eightpuzzle *eptr;
	TableNode *tptr,*minptr;

	open=new TableNode;
	open->link(start);
	close=NULL;

	clock_t start,finish;
	double time=0.0;
	start=clock();

	while(open!=NULL)
	{
		minptr=search_min();

		if (minptr->p->h() == 0)	//h����=0��Ϊ����״̬
		{
			break;
		}

		eptr=minptr->p;
		//��չ�ڵ㲢����open��
		eptr->expand();
		int i=0;
		while (eptr->child[i] != NULL && i<4)
		{
			tptr=new TableNode;
			tptr->link(eptr->child[i]);
			if ( expanded(tptr->p) == false)
			{
				//cout<<"add!"<<endl;
				add_to_opentable(tptr);
				count++;
			}
			else
			{
				//cout<<"not add!"<<endl;
			}
			i++;
			//system("pause");
		}

		//��open����ɾ����չ�ڵ㲢����close��
		add_to_closetable(minptr);
		delete_from_opentable(minptr);

	}


	finish=clock();
	time=(double)(finish-start)/CLOCKS_PER_SEC;
	if (minptr != NULL && open != NULL)
	{
		showresult(minptr->p);
		cout<<endl;
	}
	else
	{
		cout<<"�޽�"<<endl;
	}
	cout<<"��չ�ڵ�����"<<count<<endl;
	cout<<"����ʱ�䣺"<<time<<"s"<<endl;
	return 0;
}