﻿namespace Tic_Tac_Toe
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.B1 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.B4 = new System.Windows.Forms.Button();
            this.B5 = new System.Windows.Forms.Button();
            this.B6 = new System.Windows.Forms.Button();
            this.B9 = new System.Windows.Forms.Button();
            this.B8 = new System.Windows.Forms.Button();
            this.B7 = new System.Windows.Forms.Button();
            this.Start = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // B1
            // 
            this.B1.Enabled = false;
            this.B1.Location = new System.Drawing.Point(117, 84);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(40, 36);
            this.B1.TabIndex = 0;
            this.B1.UseVisualStyleBackColor = true;
            this.B1.Click += new System.EventHandler(this.B1_Click);
            // 
            // B2
            // 
            this.B2.Enabled = false;
            this.B2.Location = new System.Drawing.Point(163, 84);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(40, 36);
            this.B2.TabIndex = 0;
            this.B2.UseVisualStyleBackColor = true;
            this.B2.Click += new System.EventHandler(this.B2_Click);
            // 
            // B3
            // 
            this.B3.Enabled = false;
            this.B3.Location = new System.Drawing.Point(209, 84);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(40, 36);
            this.B3.TabIndex = 0;
            this.B3.UseVisualStyleBackColor = true;
            this.B3.Click += new System.EventHandler(this.B3_Click);
            // 
            // B4
            // 
            this.B4.Enabled = false;
            this.B4.Location = new System.Drawing.Point(117, 126);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(40, 36);
            this.B4.TabIndex = 0;
            this.B4.UseVisualStyleBackColor = true;
            this.B4.Click += new System.EventHandler(this.B4_Click);
            // 
            // B5
            // 
            this.B5.Enabled = false;
            this.B5.Location = new System.Drawing.Point(163, 126);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(40, 36);
            this.B5.TabIndex = 0;
            this.B5.UseVisualStyleBackColor = true;
            this.B5.Click += new System.EventHandler(this.B5_Click);
            // 
            // B6
            // 
            this.B6.Enabled = false;
            this.B6.Location = new System.Drawing.Point(209, 126);
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(40, 36);
            this.B6.TabIndex = 0;
            this.B6.UseVisualStyleBackColor = true;
            this.B6.Click += new System.EventHandler(this.B6_Click);
            // 
            // B9
            // 
            this.B9.Enabled = false;
            this.B9.Location = new System.Drawing.Point(209, 168);
            this.B9.Name = "B9";
            this.B9.Size = new System.Drawing.Size(40, 36);
            this.B9.TabIndex = 0;
            this.B9.UseVisualStyleBackColor = true;
            this.B9.Click += new System.EventHandler(this.B9_Click);
            // 
            // B8
            // 
            this.B8.Enabled = false;
            this.B8.Location = new System.Drawing.Point(163, 168);
            this.B8.Name = "B8";
            this.B8.Size = new System.Drawing.Size(40, 36);
            this.B8.TabIndex = 0;
            this.B8.UseVisualStyleBackColor = true;
            this.B8.Click += new System.EventHandler(this.B8_Click);
            // 
            // B7
            // 
            this.B7.Enabled = false;
            this.B7.Location = new System.Drawing.Point(117, 168);
            this.B7.Name = "B7";
            this.B7.Size = new System.Drawing.Size(40, 36);
            this.B7.TabIndex = 0;
            this.B7.UseVisualStyleBackColor = true;
            this.B7.Click += new System.EventHandler(this.B7_Click);
            // 
            // Start
            // 
            this.Start.Location = new System.Drawing.Point(12, 84);
            this.Start.Name = "Start";
            this.Start.Size = new System.Drawing.Size(74, 36);
            this.Start.TabIndex = 1;
            this.Start.Text = "Start";
            this.Start.UseVisualStyleBackColor = true;
            this.Start.Click += new System.EventHandler(this.Start_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 332);
            this.Controls.Add(this.Start);
            this.Controls.Add(this.B7);
            this.Controls.Add(this.B8);
            this.Controls.Add(this.B9);
            this.Controls.Add(this.B6);
            this.Controls.Add(this.B5);
            this.Controls.Add(this.B4);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.B1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Button B3;
        private System.Windows.Forms.Button B4;
        private System.Windows.Forms.Button B5;
        private System.Windows.Forms.Button B6;
        private System.Windows.Forms.Button B9;
        private System.Windows.Forms.Button B8;
        private System.Windows.Forms.Button B7;
        private System.Windows.Forms.Button Start;
    }
}

