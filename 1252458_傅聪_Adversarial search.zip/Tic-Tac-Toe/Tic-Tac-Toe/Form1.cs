﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_Tac_Toe
{
    public partial class Form1 : Form
    {
        ttt s;
        int a, b;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        //结束判断 10平局，1电脑，2人
        private int is_terminal(ttt s)
        {
            //横
            for (int i = 0; i < 3; i++)
            {
                if (s.state[i, 0] == s.state[i, 1] && s.state[i, 1] == s.state[i, 2])
                    return s.state[i, 0];
            }
            //纵
            for (int i = 0; i < 3; i++)
            {
                if (s.state[0, i] == s.state[1, i] && s.state[1, i] == s.state[2, i])
                    return s.state[0, i];
            }
            //对角线
            if (s.state[0, 0] == s.state[1, 1] && s.state[1, 1] == s.state[2, 2])
                return s.state[0, 0];
            if (s.state[0, 2] == s.state[1, 1] && s.state[1, 1] == s.state[2, 0])
                return s.state[0, 2];

            //平局
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (s.state[i,j] == 0)
                    {
                        return 0;
                    }
                }
            }

            return 10;
        }

        //max
        private int max(ttt s)
        {
            int r = is_terminal(s);
            int v=-9999;
            if (r != 0)
            {
                if (r == 1)
                    return 2;
                else if (r == -1)
                    return -2;
                else
                    return 0;
            }
            s.action(1);
            for (int i = 0; i < s.num; i++)
            {
                int k = min(s.child[i]);
                if ( v < k )
                {
                    v = k;
                    s.n = i;
                }
            }
            //MessageBox.Show("max v"+v.ToString()+"s.n"+s.n.ToString());
            return v;
        }

        //min
        private int min(ttt s)
        {
            
            int r = is_terminal(s);
            int v=9999;
            if (r != 0)
            {
                if (r == 1)
                    return 2;
                else if (r == -1)
                    return -2;
                else
                    return 0;
            }
            s.action(-1);
            for (int i = 0; i < s.num; i++)
            {
                int k = max(s.child[i]);
                if (v > k)
                {
                    v = k;
                    s.n = i;
                }
            }
            //MessageBox.Show("min v" + v.ToString());
            return v;
        }

        //search
        private ttt search(ttt s)
        {
            int v;
            v = max(s);
            //MessageBox.Show("search");
            //MessageBox.Show("s.n  "+s.n.ToString()+" max:"+v.ToString());
            return s.child[s.n];
        }

        private void Start_Click(object sender, EventArgs e)
        {
            B1.Enabled = true;
            B2.Enabled = true;
            B3.Enabled = true;
            B4.Enabled = true;
            B5.Enabled = true;
            B6.Enabled = true;
            B7.Enabled = true;
            B8.Enabled = true;
            B9.Enabled = true;
            B1.Text = "";
            B2.Text = "";
            B3.Text = "";
            B4.Text = "";
            B5.Text = "";
            B6.Text = "";
            B7.Text = "";
            B8.Text = "";
            B9.Text = "";
            s = new ttt();
            a = 99999;
            b = -99999;
        }

        private void change(ttt s)
        {
            int k=1;
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                {
                    if (s.state[i,j] != 1)
                        continue;
                    k = i * 3 + j + 1;
                    if (k == 1)
                    {
                        B1.Enabled = false;
                        B1.Text = "X";
                    }
                    else if (k == 2)
                    {
                        B2.Enabled = false;
                        B2.Text = "X";
                    }
                    else if (k == 3)
                    {
                        B3.Enabled = false;
                        B3.Text = "X";
                    }
                    else if (k == 4)
                    {
                        B4.Enabled = false;
                        B4.Text = "X";
                    }
                    else if (k == 5)
                    {
                        B5.Enabled = false;
                        B5.Text = "X";
                    }
                    else if (k == 6)
                    {
                        B6.Enabled = false;
                        B6.Text = "X";
                    }
                    else if (k == 7)
                    {
                        B7.Enabled = false;
                        B7.Text = "X";
                    }
                    else if (k == 8)
                    {
                        B8.Enabled = false;
                        B8.Text = "X";
                    }
                    else if (k == 9)
                    {
                        B9.Enabled = false;
                        B9.Text = "X";
                    }
                }
            if (is_terminal(s) == 1)
                MessageBox.Show("You lose");
            else if (is_terminal(s) == -1)
                MessageBox.Show("You win");
            else if (is_terminal(s) == 10)
                MessageBox.Show("Draw");
        }

        private void B1_Click(object sender, EventArgs e)
        {
            s.state[0, 0] = -1;
            B1.Enabled = false;
            B1.Text = "O";
            s.num = 0;
            max(s);
            s = s.child[s.n];
            change(s);
        }

        private void B2_Click(object sender, EventArgs e)
        {
            s.state[0, 1] = -1;
            B2.Enabled = false;
            B2.Text = "O";
            s.num = 0;
            max(s);
            s = s.child[s.n];
            change(s);
        }

        private void B3_Click(object sender, EventArgs e)
        {
            s.state[0, 2] = -1;
            B3.Enabled = false;
            B3.Text = "O";
            s.num = 0;
            max(s);
            s = s.child[s.n];
            change(s);
        }

        private void B4_Click(object sender, EventArgs e)
        {
            s.state[1, 0] = -1;
            B4.Enabled = false;
            B4.Text = "O";
            s.num = 0;
            max(s);
            s = s.child[s.n];
            change(s);
        }

        private void B5_Click(object sender, EventArgs e)
        {
            s.state[1, 1] = -1;
            B5.Enabled = false;
            B5.Text = "O";
            s.num = 0;
            max(s);
            s = s.child[s.n];
            change(s);
        }

        private void B6_Click(object sender, EventArgs e)
        {
            s.state[1, 2] = -1;
            B6.Enabled = false;
            B6.Text = "O";
            s.num = 0;
            max(s);
            s = s.child[s.n];
            change(s);
        }

        private void B7_Click(object sender, EventArgs e)
        {
            s.state[2, 0] = -1;
            B7.Enabled = false;
            B7.Text = "O";
            s.num = 0;
            max(s);
            s = s.child[s.n];
            change(s);
        }

        private void B8_Click(object sender, EventArgs e)
        {
            s.state[2, 1] = -1;
            B8.Enabled = false;
            B8.Text = "O";
            s.num = 0;
            max(s);
            s = s.child[s.n];
            change(s);
        }

        private void B9_Click(object sender, EventArgs e)
        {
            s.state[2, 2] = -1;
            B9.Enabled = false;
            B9.Text = "O";
            s.num = 0;
            max(s);
            s = s.child[s.n];
            change(s);
        }
    }

    class ttt
    {
        public int[,] state = new int[3, 3];
        public ttt[] child = new ttt[9];
        public int num;
        public int n;
        public ttt()
        {
            n = 0;
            num = 0;
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    state[i, j] = 0;
        }
        public void action(int p)
        {
            ttt s;
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                {
                    if (this.state[i, j] == 0)
                    {
                        s = new ttt();
                        for (int k = 0; k < 3; k++)
                            for (int q = 0; q < 3; q++)
                                s.state[k,q] = this.state[k, q];
                        s.state[i, j] = p;
                        this.child[num++] = s;
                    }
                }
        }
    }
}